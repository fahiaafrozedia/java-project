package util;

import java.io.FileWriter;
import java.io.IOException;

public class FileHandler {

    public static void saveReport(String data) throws IOException {
        FileWriter writer = new FileWriter("stress_report.txt", true);
        writer.write(data);
        writer.close();
    }

    // Method Overloading
    public static void saveReport(String name, int score, String level) throws IOException {
        saveReport("Name: " + name + ", Score: " + score + ", Level: " + level + "\n");
    }
}
