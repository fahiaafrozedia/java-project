package model;

public class GeneralUser extends User {

    public GeneralUser(String name, int age, int sleepHours) {
        super(name, age, sleepHours);
    }

    @Override
    public void calculateStress() {
        int score = 50 - (getSleepHours() * 6);
        setStressScore(Math.max(score, 0));
    }

}
