package model;

public class EmployeeUser extends User {

    private int workHours;

    public EmployeeUser(String name, int age, int sleepHours, int workHours) {
        super(name, age, sleepHours);
        this.workHours = workHours;
    }

    @Override
    public void calculateStress() {
        int score = (workHours * 8) - (getSleepHours() * 4);
        setStressScore(Math.max(score, 0));
    }

}
