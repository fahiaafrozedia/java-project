package model;

public class StudentUser extends User {

    private int studyHours;

    public StudentUser(String name, int age, int sleepHours, int studyHours) {
        super(name, age, sleepHours);
        this.studyHours = studyHours;
    }

    @Override
    public void calculateStress() {
        int score = (studyHours * 10) - (getSleepHours() * 5);
        setStressScore(Math.max(score, 0));
    }

}
