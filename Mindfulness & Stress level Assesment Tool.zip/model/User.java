package model;

public abstract class User {
	private String name;
    private int age;
    private int sleepHours;
    private int stressScore;

    public User(String name, int age, int sleepHours) {
        this.name = name;
        this.age = age;
        this.sleepHours = sleepHours;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public int getSleepHours() { return sleepHours; }

    public int getStressScore() { return stressScore; }
    protected void setStressScore(int stressScore) {
        this.stressScore = stressScore;
    }

    public abstract void calculateStress();

}
