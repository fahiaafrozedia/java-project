package ui;

import model.*;
import service.*;
import util.*;
import exception.*;

import javax.swing.*;
//import java.awt.event.*;
import java.io.IOException;

public class MainUI {

    public static void launch() {
        JFrame frame = new JFrame("Mindfulness & Stress Assessment Tool");
        frame.setSize(400, 300);
        frame.setLayout(null);

        JTextField name = new JTextField();
        JTextField sleep = new JTextField();
        JButton assess = new JButton("Assess Stress");

        name.setBounds(120, 30, 150, 25);
        sleep.setBounds(120, 70, 150, 25);
        assess.setBounds(120, 120, 150, 30);

        frame.add(new JLabel("Name")).setBounds(40, 30, 80, 25);
        frame.add(new JLabel("Sleep Hours")).setBounds(40, 70, 80, 25);
        frame.add(name);
        frame.add(sleep);
        frame.add(assess);

        assess.addActionListener(e -> {
            try {
                int sleepHours = Integer.parseInt(sleep.getText());
                if (sleepHours <= 0)
                    throw new InvalidStressInputException("Invalid sleep hours");

                User user = new GeneralUser(name.getText(), 20, sleepHours);
                user.calculateStress();

                StressCalculator calc = new StressCalculator();
                String level = calc.getStressLevel(user.getStressScore());

                FileHandler.saveReport(user.getName(), user.getStressScore(), level);
                JOptionPane.showMessageDialog(frame, level);

            } catch (InvalidStressInputException | IOException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
