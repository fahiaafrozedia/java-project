package service;

public class StressCalculator implements StressAssessment {
	 @Override
	    public String getStressLevel(int score) {
	        if (score < 30)
	            return "Low Stress – Keep practicing mindfulness";
	        else if (score < 60)
	            return "Moderate Stress – Meditation recommended";
	        else
	            return "High Stress – Immediate mindfulness needed";
	    }

}
