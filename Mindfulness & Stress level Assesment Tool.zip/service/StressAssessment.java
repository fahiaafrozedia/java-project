package service;

public interface StressAssessment {
	String getStressLevel(int score);


}
