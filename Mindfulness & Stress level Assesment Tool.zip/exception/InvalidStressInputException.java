package exception;

public class InvalidStressInputException extends Exception {
	 public InvalidStressInputException(String message) {
	        super(message);
	    }

}
